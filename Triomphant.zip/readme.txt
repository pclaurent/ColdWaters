"Le Triomphant" mod for Cold Waters, including new F21 torpedo and new sonar DMUX-80

Installation:

1. Create a folder "override", if not already there, in your CW installation directory (default: C:\Program Files (x86)\Steam\steamapps\common\Cold Waters\ColdWaters_Data\StreamingAssets)

2. Open the zip package and copy its contents (including subdirs) in override dir.

3. If you don't have the files sensors.txt and weapons.txt in your override directory, copy them from the default folder.

4. In the override directory, open sensors.txt and add the contents of "sensors - dmux80 only.txt"

5. In the override directory, open weapons.txt and add the contents of "weapons - f21 only.txt"

6. In the override/vessels directory: if you don't have a file vessel_list.txt, copy it from default/vessels.

7. Edit the override/vessel_list.txt file and add a line "fra_ssbn_triomphant"

